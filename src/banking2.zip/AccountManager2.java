package banking2;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Scanner;

//컨트롤 클래스로 프로그램의 전반적인 기능을 구현한다.
public class AccountManager2 {
	HashSet<Account2> accountHashSet;
	
	public AccountManager2() {
		accountHashSet = new HashSet<>();
	}
	

	// 계좌개설을 위한 메서드
	public void makeAccount(int choice) {

		Scanner scan = new Scanner(System.in);
		String iAccountNum, iName, iRating;

		int iBalance;
		// 계좌 비교
		System.out.println("1.보통계좌");
		System.out.println("2.신용신뢰계좌");
		choice = scan.nextInt();
		while (true) {
			if (choice == 1) {
				System.out.println("보통계좌");
				System.out.println("");
				scan.nextLine();
				System.out.print("계좌번호:");
				iAccountNum = scan.nextLine();

				System.out.print("고객이름 :");
				iName = scan.nextLine();

				System.out.print("잔고 :");
				iBalance = scan.nextInt();

				System.out.print("기본이자>");
				int inter = scan.nextInt();
				scan.nextLine();
				NormalAccount2 normal = new NormalAccount2(iAccountNum, iName, iBalance, inter);

				if (accountHashSet.add(normal)) {
					accountHashSet.add(normal);
				} else {
					System.out.println("중복된 계좌가 발생하였습니다");
					System.out.println("덮어쓸려면 Y 취소할려면 N");
					String overlap = scan.nextLine();
					if (overlap.equalsIgnoreCase("Y")) {
						accountHashSet.remove(normal);
						accountHashSet.add(normal);
					} else if (overlap.equalsIgnoreCase("N")) {
						System.out.println("취소합니다");
						return;
					}
				}
			} else if (choice == 2) {
				System.out.println("신용신뢰계좌");
				System.out.println("");
				scan.nextLine();
				System.out.print("계좌번호:");
				iAccountNum = scan.nextLine();

				System.out.print("고객이름 :");
				iName = scan.nextLine();

				System.out.print("잔고 :");
				iBalance = scan.nextInt();

				System.out.print("기본이자>");
				int inter = scan.nextInt();
				scan.nextLine();
				System.out.print("등급>");
				iRating = scan.nextLine();
				HighCreditAccount2 high = new HighCreditAccount2(iAccountNum, iName, iBalance, inter, iRating);

				if (accountHashSet.add(high)) {
					accountHashSet.add(high);
				} else {
					System.out.println("중복된 계좌가 발생하였습니다");
					System.out.println("덮어쓸려면 Y 취소할려면 N");
					String overlap = scan.nextLine();
					if (overlap.equalsIgnoreCase("Y")) {
						accountHashSet.remove(high);
						accountHashSet.add(high);
					} else if (overlap.equalsIgnoreCase("N")) {
						System.out.println("취소합니다");
						return;
					}
				}
			}
			System.out.println(" 완료되었습니다.");
			break;
		}
	}

	// 정보를 출력하는 메서드
	public void showAccInfo() {
		System.out.println("***계좌정보출력***");
		/*
		 * for (int i = 0; i < accountArr; i++) { System.out.println("-------------");
		 * accountList[i].showAccInfo(); System.out.println("-------------"); }
		 */
		for (Account2 acc2 : accountHashSet) {

			acc2.showAccInfo();

		}

		System.out.println("전체계좌정보 출력이 완료되었습니다.");
	}

	// 입금하는 메서드
	public void depositMoney() {
		boolean isFind = false;
		Scanner scan = new Scanner(System.in);
		System.out.println("계좌번호와 입금할 금액을 입력하세요");
		System.out.println("계좌번호:");
		String searchaccountnum = scan.nextLine();

		// for (int i = 0; i < accountArr; i++) {
		for (Account2 acc2 : accountHashSet) {

			if (searchaccountnum.equals(acc2.accountnum)) {

				try {
					System.out.println(" 입금액:");
					int addnum = scan.nextInt();
					if (addnum < 0) {
						System.out.println("마이너스 금액은 입급할 수 없습니다.");
						return;
					} else if (addnum % 500 != 0) {
						System.out.println("500원 단위로 입금하세요.");
						return;
					} else {
						acc2.setBalance(ICustomDefine2.DEPOSITS, addnum);
						System.out.println(" 입금이 완료되었습니다.");
						isFind = true;
					}
				} catch (InputMismatchException e) {
					System.out.println("문자를 입력할 수 없습니다.");
				}
			}
		}
		if (isFind == false)
			System.out.println("***계좌번호가 틀렸습니다.***");
	}

	// 출금하는 메서드
	public void withdrawMoney() {
		boolean isFind = false;
		Scanner scan = new Scanner(System.in);
		System.out.println("계좌번호 입력하세요");
		String searchaccountnum = scan.nextLine();

		// for (int i = 0; i < accountArr; i++) {
		for (Account2 acc2 : accountHashSet) {
			if (searchaccountnum.equals(acc2.accountnum)) {

				System.out.println(" 출금할 금액을 입력하세요.");
				int addnum = scan.nextInt();
				scan.nextLine();
				if (addnum < 0) {
					System.out.println("마이너스 금액은 출금할 수 없습니다.");
					return;
				} else if (addnum > acc2.balance) {
					System.out.println("잔고가 부족합니다 전체잔고를 출력할까요?");
					System.out.println("Y: 전체처리, N출금요청취소");
					String addnym = scan.nextLine();
					if ("Y".equalsIgnoreCase(addnym)) {
						System.out.println("전체처리");
						isFind = true;
					} else if ("N".equalsIgnoreCase(addnym)) {
						System.out.println("출금요청 취소");
						return;
					}
				} else {
					System.out.println(" 출금이 완료되었습니다.");
					isFind = true;
				}
				acc2.setBalance(ICustomDefine2.WITHDRAWS, addnum);
			}
		}
		if (isFind == false)
			System.out.println("***계좌번호가 틀렸습니다.***");
	}

	public void saveAccountInfo() {
		ObjectOutputStream oos =null;
		try {
			oos = new ObjectOutputStream (new FileOutputStream("src/banking2/AccountInfo_r.obj"));
			for(Account2 ac2 : accountHashSet) {
				oos.writeObject(ac2);
			}				
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void readAccountInfo() {
		ObjectInputStream ois = null;
				try {
					ois = new ObjectInputStream(new FileInputStream("src/banking2/AccountInfo_r.obj"));
					while(true) {
						accountHashSet.add((Account2)ois.readObject());
					}
				} catch (EOFException e) {
					System.out.println("파일불러오기 끝");
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
		
	}
//	void AutoSaver() {
//		PrintWriter out = null;
//				
//			try {
//				out =new PrintWriter(new FileWriter("src/banking2/AutoSaveAccount.txt"));
//			} catch (FileNotFoundException e) {
//				e.printStackTrace();
//			} catch (IOException e) {
//				e.printStackTrace();
//			} catch (Exception e) {
//			}
//		
//		out.close();
//		
//		
//		System.out.println("AutoSaveAccount.txt 가 생성되었습니다");
//	}
	
	

}
