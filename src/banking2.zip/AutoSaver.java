package banking2;

public class AutoSaver extends Thread {

	
	@Override
	public void run() {
		//무한루프로 구성되어있고 별도의 탈출조건을 만들지 않는다.
		//getName() : 쓰레드명을 반환하는 getter
		while(true) {
			System.out.printf("[쓰레드명:%s]Jazz가 흘러요~%n", getName());
			try {
				sleep(3000);
				System.out.println("3초마다 자동저장!!");
			}
			catch (InterruptedException e) {
				System.out.println("자동저장시 오류발생 ㅜㅜ");
			}
			
		}
	}
	@Override
	public String toString() {
		return super.toString();
	}

}
