package banking2;

import java.util.Scanner;

public class BankingSystemMain2 {

	public static void showMenu() {
		System.out.println("-----Menu------");
		System.out.println("1.계좌계설 ");
		System.out.println("2.입금 ");
		System.out.println("3.출금");
		System.out.println("4.전체계좌정보출력");
		System.out.println("5.프로그램종료");
		System.out.println("6.저장옵션");
		System.out.println("7.불러오기옵션");
	}

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		AccountManager2 hunarr = new AccountManager2();
		MenuSelectException2 ex = new MenuSelectException2();
		
		
		while (true) {
			showMenu();

			try {
				int choice = scan.nextInt();
				switch (choice) {
				case ICustomDefine2.MAKE:
					hunarr.makeAccount(choice);
					break;
				case ICustomDefine2.DEPOSIT:
					hunarr.depositMoney();
					break;
				case ICustomDefine2.WITHDRAW:
					hunarr.withdrawMoney();
					break;
				case ICustomDefine2.INQUIRE:
					hunarr.showAccInfo();
					break;
				case ICustomDefine2.EXIT:
					System.out.println("프로그램종료");
					
					System.exit(0);
				case 6:
					System.out.println("저장합니다.");
					hunarr.saveAccountInfo();
					break;
				case 7:
					System.out.println("불러오기");
					hunarr.readAccountInfo();
					break;
				default:
					throw ex;
				}
			} catch (MenuSelectException2 e) {
				System.out.println(e.getMessage());
			} catch (Exception e) {
				System.out.println();
				scan.nextLine();
			}

		}

	}
}
